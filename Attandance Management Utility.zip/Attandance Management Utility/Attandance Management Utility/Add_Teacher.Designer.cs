﻿namespace Attandance_Management_Utility
{
    partial class Add_Teacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exit = new System.Windows.Forms.Button();
            this.add_teacher_cmbx = new System.Windows.Forms.Button();
            this.email_txt = new System.Windows.Forms.TextBox();
            this.phone_txt = new System.Windows.Forms.TextBox();
            this.emp_id_txt = new System.Windows.Forms.TextBox();
            this.name_txt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.title_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(247, 305);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(83, 23);
            this.exit.TabIndex = 30;
            this.exit.Text = "Cancel";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // add_teacher_cmbx
            // 
            this.add_teacher_cmbx.Location = new System.Drawing.Point(72, 305);
            this.add_teacher_cmbx.Name = "add_teacher_cmbx";
            this.add_teacher_cmbx.Size = new System.Drawing.Size(96, 23);
            this.add_teacher_cmbx.TabIndex = 29;
            this.add_teacher_cmbx.Text = "Add Teacher";
            this.add_teacher_cmbx.UseVisualStyleBackColor = true;
            this.add_teacher_cmbx.Click += new System.EventHandler(this.Add_teacher_cmbx_Click);
            // 
            // email_txt
            // 
            this.email_txt.Location = new System.Drawing.Point(179, 251);
            this.email_txt.Name = "email_txt";
            this.email_txt.Size = new System.Drawing.Size(151, 20);
            this.email_txt.TabIndex = 27;
            // 
            // phone_txt
            // 
            this.phone_txt.Location = new System.Drawing.Point(179, 213);
            this.phone_txt.Name = "phone_txt";
            this.phone_txt.Size = new System.Drawing.Size(151, 20);
            this.phone_txt.TabIndex = 26;
            // 
            // emp_id_txt
            // 
            this.emp_id_txt.Location = new System.Drawing.Point(179, 169);
            this.emp_id_txt.Name = "emp_id_txt";
            this.emp_id_txt.Size = new System.Drawing.Size(151, 20);
            this.emp_id_txt.TabIndex = 24;
            // 
            // name_txt
            // 
            this.name_txt.Location = new System.Drawing.Point(179, 122);
            this.name_txt.Name = "name_txt";
            this.name_txt.Size = new System.Drawing.Size(151, 20);
            this.name_txt.TabIndex = 23;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(69, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "E-Mail";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(69, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Phone Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Employee ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Name";
            // 
            // title_lbl
            // 
            this.title_lbl.AutoSize = true;
            this.title_lbl.Location = new System.Drawing.Point(176, 63);
            this.title_lbl.Name = "title_lbl";
            this.title_lbl.Size = new System.Drawing.Size(69, 13);
            this.title_lbl.TabIndex = 16;
            this.title_lbl.Text = "Add Teacher";
            // 
            // Add_Teacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 360);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.add_teacher_cmbx);
            this.Controls.Add(this.email_txt);
            this.Controls.Add(this.phone_txt);
            this.Controls.Add(this.emp_id_txt);
            this.Controls.Add(this.name_txt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.title_lbl);
            this.Name = "Add_Teacher";
            this.Text = "Add_Teacher";
            this.Load += new System.EventHandler(this.Add_Teacher_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button add_teacher_cmbx;
        private System.Windows.Forms.TextBox email_txt;
        private System.Windows.Forms.TextBox phone_txt;
        private System.Windows.Forms.TextBox emp_id_txt;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label title_lbl;
    }
}
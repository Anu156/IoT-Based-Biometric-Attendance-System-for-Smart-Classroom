﻿namespace Attandance_Management_Utility
{
    partial class teacher_device_relationship
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.teacher_cmbx = new System.Windows.Forms.ComboBox();
            this.class_cmbx = new System.Windows.Forms.ComboBox();
            this.add_btn = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.fp_id = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.subject_txt = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.fp_id)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(114, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Teacher Class Relation";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Teacher Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Class Name";
            // 
            // teacher_cmbx
            // 
            this.teacher_cmbx.FormattingEnabled = true;
            this.teacher_cmbx.Location = new System.Drawing.Point(162, 80);
            this.teacher_cmbx.Name = "teacher_cmbx";
            this.teacher_cmbx.Size = new System.Drawing.Size(156, 21);
            this.teacher_cmbx.TabIndex = 3;
            this.teacher_cmbx.SelectedIndexChanged += new System.EventHandler(this.Teacher_cmbx_SelectedIndexChanged);
            // 
            // class_cmbx
            // 
            this.class_cmbx.FormattingEnabled = true;
            this.class_cmbx.Location = new System.Drawing.Point(162, 121);
            this.class_cmbx.Name = "class_cmbx";
            this.class_cmbx.Size = new System.Drawing.Size(156, 21);
            this.class_cmbx.TabIndex = 4;
            // 
            // add_btn
            // 
            this.add_btn.Location = new System.Drawing.Point(51, 253);
            this.add_btn.Name = "add_btn";
            this.add_btn.Size = new System.Drawing.Size(100, 23);
            this.add_btn.TabIndex = 5;
            this.add_btn.Text = "Add Relationship";
            this.add_btn.UseVisualStyleBackColor = true;
            this.add_btn.Click += new System.EventHandler(this.Add_btn_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(226, 253);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(92, 23);
            this.cancel.TabIndex = 6;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(51, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Fingerprint ID";
            // 
            // fp_id
            // 
            this.fp_id.Location = new System.Drawing.Point(162, 163);
            this.fp_id.Name = "fp_id";
            this.fp_id.Size = new System.Drawing.Size(156, 20);
            this.fp_id.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Subject";
            // 
            // subject_txt
            // 
            this.subject_txt.Location = new System.Drawing.Point(162, 203);
            this.subject_txt.Name = "subject_txt";
            this.subject_txt.Size = new System.Drawing.Size(156, 20);
            this.subject_txt.TabIndex = 10;
            // 
            // teacher_device_relationship
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(391, 305);
            this.Controls.Add(this.subject_txt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.fp_id);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.add_btn);
            this.Controls.Add(this.class_cmbx);
            this.Controls.Add(this.teacher_cmbx);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "teacher_device_relationship";
            this.Text = "Teacher Device Relationship";
            this.Load += new System.EventHandler(this.Teacher_device_relationship_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fp_id)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox teacher_cmbx;
        private System.Windows.Forms.ComboBox class_cmbx;
        private System.Windows.Forms.Button add_btn;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown fp_id;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox subject_txt;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Attandance_Management_Utility
{
    public partial class Add_Teacher : Form
    {
        public Add_Teacher()
        {
            InitializeComponent();
        }

        private void Add_Teacher_Load(object sender, EventArgs e)
        {

        }

        private void Add_teacher_cmbx_Click(object sender, EventArgs e)
        {
            if (IsValid())
            {
                Teacher teacher = new Teacher();
                teacher.Name = name_txt.Text;
                teacher.Email = email_txt.Text;
                teacher.Emp_id = emp_id_txt.Text;
                teacher.Contact = phone_txt.Text;
                teacher.AddToDb();
                name_txt.Text = "";
                email_txt.Text = "";
                emp_id_txt.Text = "";
                phone_txt.Text = "";
            }
        }

        private bool IsValid()
        {
            if (name_txt.Text != "" && emp_id_txt.Text != "")
            {
                if (phone_txt.Text.Equals("") && email_txt.Text.Equals(""))
                {
                    MessageBox.Show("Enter either of E-Mail or Phone Number.");
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                MessageBox.Show("Enter All required details.");
                return false;
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}

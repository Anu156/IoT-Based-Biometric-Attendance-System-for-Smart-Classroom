﻿namespace Attandance_Management_Utility
{
    partial class Add_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.title_lbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.name_txt = new System.Windows.Forms.TextBox();
            this.prn_txt = new System.Windows.Forms.TextBox();
            this.fp_txt = new System.Windows.Forms.TextBox();
            this.phone_txt = new System.Windows.Forms.TextBox();
            this.email_txt = new System.Windows.Forms.TextBox();
            this.class_cmbx = new System.Windows.Forms.ComboBox();
            this.add_student_cmbx = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // title_lbl
            // 
            this.title_lbl.AutoSize = true;
            this.title_lbl.Location = new System.Drawing.Point(152, 32);
            this.title_lbl.Name = "title_lbl";
            this.title_lbl.Size = new System.Drawing.Size(66, 13);
            this.title_lbl.TabIndex = 0;
            this.title_lbl.Text = "Add Student";
            this.title_lbl.Click += new System.EventHandler(this.Title_lbl_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Class";
            this.label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "PRN";
            this.label3.Click += new System.EventHandler(this.Label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Fingerprint ID";
            this.label4.Click += new System.EventHandler(this.Label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Phone Number";
            this.label5.Click += new System.EventHandler(this.Label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 279);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "E-Mail";
            this.label6.Click += new System.EventHandler(this.Label6_Click);
            // 
            // name_txt
            // 
            this.name_txt.Location = new System.Drawing.Point(155, 91);
            this.name_txt.Name = "name_txt";
            this.name_txt.Size = new System.Drawing.Size(151, 20);
            this.name_txt.TabIndex = 7;
            this.name_txt.TextChanged += new System.EventHandler(this.Name_txt_TextChanged);
            // 
            // prn_txt
            // 
            this.prn_txt.Location = new System.Drawing.Point(155, 165);
            this.prn_txt.Name = "prn_txt";
            this.prn_txt.Size = new System.Drawing.Size(151, 20);
            this.prn_txt.TabIndex = 9;
            this.prn_txt.TextChanged += new System.EventHandler(this.Prn_txt_TextChanged);
            // 
            // fp_txt
            // 
            this.fp_txt.Location = new System.Drawing.Point(155, 202);
            this.fp_txt.Name = "fp_txt";
            this.fp_txt.Size = new System.Drawing.Size(151, 20);
            this.fp_txt.TabIndex = 10;
            this.fp_txt.TextChanged += new System.EventHandler(this.Fp_txt_TextChanged);
            // 
            // phone_txt
            // 
            this.phone_txt.Location = new System.Drawing.Point(155, 241);
            this.phone_txt.Name = "phone_txt";
            this.phone_txt.Size = new System.Drawing.Size(151, 20);
            this.phone_txt.TabIndex = 11;
            this.phone_txt.TextChanged += new System.EventHandler(this.Phone_txt_TextChanged);
            // 
            // email_txt
            // 
            this.email_txt.Location = new System.Drawing.Point(155, 279);
            this.email_txt.Name = "email_txt";
            this.email_txt.Size = new System.Drawing.Size(151, 20);
            this.email_txt.TabIndex = 12;
            this.email_txt.TextChanged += new System.EventHandler(this.Email_txt_TextChanged);
            // 
            // class_cmbx
            // 
            this.class_cmbx.FormattingEnabled = true;
            this.class_cmbx.Location = new System.Drawing.Point(155, 128);
            this.class_cmbx.Name = "class_cmbx";
            this.class_cmbx.Size = new System.Drawing.Size(151, 21);
            this.class_cmbx.TabIndex = 13;
            this.class_cmbx.SelectedIndexChanged += new System.EventHandler(this.Class_cmbx_SelectedIndexChanged);
            // 
            // add_student_cmbx
            // 
            this.add_student_cmbx.Location = new System.Drawing.Point(48, 333);
            this.add_student_cmbx.Name = "add_student_cmbx";
            this.add_student_cmbx.Size = new System.Drawing.Size(75, 23);
            this.add_student_cmbx.TabIndex = 14;
            this.add_student_cmbx.Text = "Add Student";
            this.add_student_cmbx.UseVisualStyleBackColor = true;
            this.add_student_cmbx.Click += new System.EventHandler(this.Add_student_cmbx_Click);
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(231, 333);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(75, 23);
            this.exit.TabIndex = 15;
            this.exit.Text = "Cancel";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Add_Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 416);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.add_student_cmbx);
            this.Controls.Add(this.class_cmbx);
            this.Controls.Add(this.email_txt);
            this.Controls.Add(this.phone_txt);
            this.Controls.Add(this.fp_txt);
            this.Controls.Add(this.prn_txt);
            this.Controls.Add(this.name_txt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.title_lbl);
            this.Name = "Add_Student";
            this.Text = "Add_Student";
            this.Load += new System.EventHandler(this.Add_Student_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title_lbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.TextBox prn_txt;
        private System.Windows.Forms.TextBox fp_txt;
        private System.Windows.Forms.TextBox phone_txt;
        private System.Windows.Forms.TextBox email_txt;
        private System.Windows.Forms.ComboBox class_cmbx;
        private System.Windows.Forms.Button add_student_cmbx;
        private System.Windows.Forms.Button exit;
    }
}
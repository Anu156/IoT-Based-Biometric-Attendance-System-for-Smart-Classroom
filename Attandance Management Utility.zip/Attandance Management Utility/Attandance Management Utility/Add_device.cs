﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Attandance_Management_Utility
{
    public partial class Add_device : Form
    {
        public Add_device()
        {
            InitializeComponent();
        }

        private void Add_device_btn_Click(object sender, EventArgs e)
        {
            if (IsValid())
            {
                TakeEntriesAndUpdateDatabase();
            }
        }

        private bool IsValid()
        {
            if (class_name_txt.Text != "" && device_id_txt.Text != "") { return true; } else return false;
        }

        private void TakeEntriesAndUpdateDatabase()
        {
            Device device = new Device();
            device.Class_name = class_name_txt.Text;
            device.Dev_id = device_id_txt.Text;
            device.AddtoDb();
            
                class_name_txt.Text = "";
                device_id_txt.Text = "";
            
           
        }

        private void Cancel_btn_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}

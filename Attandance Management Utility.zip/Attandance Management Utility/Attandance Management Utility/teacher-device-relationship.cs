﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Attandance_Management_Utility
{
    public partial class teacher_device_relationship : Form
    {
        database db = new database();
        DataTable teachers;
        string teacher_id;
        public teacher_device_relationship()
        {
            InitializeComponent();
        }

        private void Teacher_device_relationship_Load(object sender, EventArgs e)
        {
            LoadFacultyAndClass();
        }

        private void LoadFacultyAndClass()
        {
            DataTable faculty = db.Fetch("Select * from teacher");
            teachers = faculty;
            foreach (DataRow dataRow in faculty.Rows)
            {
                teacher_cmbx.Items.Add("" + dataRow[1] + " | " + dataRow[2]);
            }
            DataTable classes = db.Fetch("Select * from device");
            foreach (DataRow dataRow in classes.Rows)
            {
                class_cmbx.Items.Add("" + dataRow[1] );
            }
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void Add_btn_Click(object sender, EventArgs e)
        {
            if (subject_txt.Text != "" && class_cmbx.Text != "" && teacher_cmbx.Text != "" && fp_id.Value != 0)
            {
                db.InsertToDb("INSERT INTO `teacher-class-relation`(`device_id`, `teacher_id`, `subject`, `fp_id`) VALUES ((Select device_id from device where class='" + class_cmbx.Text + "')," + teacher_id + ",'" + subject_txt.Text + "'," + fp_id.Value + ")");
                subject_txt.Text = "";
                class_cmbx.Text = "";
                teacher_cmbx.Text = "";
                fp_id.Value = 0;

            }
            else
            {
                MessageBox.Show("Enter all values..!!");
            }
        }

        private void Teacher_cmbx_SelectedIndexChanged(object sender, EventArgs e)
        {
            teacher_id = teachers.Rows[teacher_cmbx.SelectedIndex][0].ToString();
        }
    }
}

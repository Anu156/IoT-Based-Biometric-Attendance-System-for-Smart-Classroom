﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Attandance_Management_Utility
{
    
    class database
    {
        static string connString = ConfigurationManager.ConnectionStrings["constr"].ConnectionString.ToString();
        MySqlConnection conn = new MySqlConnection(connString);
        
        public int InsertToDb(string query)
        {
            try
            {
                connect(true);
                MySqlCommand mySql = new MySqlCommand(query, conn);
                mySql.ExecuteNonQuery();
                connect(false);
                return -9;
                
            }
            catch(Exception ex)
            {
                connect(false);
                return 0;
            }
        }
        public DataTable Fetch(string query)
        {
            DataTable result = new DataTable("Fetch Results");
            connect(true);
            MySqlCommand command = new MySqlCommand(query,conn);
            result.Load(command.ExecuteReader());
            connect(false);
            return result;
        }
        public int Update(string query)
        {
            return 0;
        }
        public void connect(bool toggle)
        {
            try
            {
                if (toggle == true)
                {
                    conn.Open();
                }
                else
                {
                    conn.Close();
                }
            }
            catch(Exception ex)
            {
                conn.Close();
            }
            
        }
    }
}

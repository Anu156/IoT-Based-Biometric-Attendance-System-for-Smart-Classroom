﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Attandance_Management_Utility
{
    class student
    {
        database db= new database();
        string name, roll_number, fp_id, _class, contact, email;

        public string Name { get => name; set => name = value; }
        public string Roll_number { get => roll_number; set => roll_number = value; }
        public string Fp_id { get => fp_id; set => fp_id = value; }
        public string Class { get => _class; set => _class = value; }
        public string Contact { get => contact; set => contact = value; }
        public string Email { get => email; set => email = value; }
        public int AddToDB()
        {
            string query = "INSERT INTO `student`(`Name`, `PRN`, `fp_id`, `Class`, `contact`, `email`) VALUES ('"+Name+"',"+Roll_number+","+Fp_id+",'"+Class+"',"+Contact+",'"+Email+"')";
            db.InsertToDb(query);
            return 0;
        }
    }
    
}

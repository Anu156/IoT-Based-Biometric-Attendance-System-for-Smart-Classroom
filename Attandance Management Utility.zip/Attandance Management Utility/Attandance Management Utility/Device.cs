﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Attandance_Management_Utility
{
    class Device
    {
        database db = new database();
        string dev_id, class_name;

        public string Dev_id { get => dev_id; set => dev_id = value; }
        public string Class_name { get => class_name; set => class_name = value; }
        public int AddtoDb()
        {
            string query = "INSERT INTO `device`(`device_id`, `class`) VALUES ("+Dev_id+",'"+Class_name+"')";
            db.InsertToDb(query);
            return 0;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using Excel = Microsoft.Office.Interop.Excel;

namespace Attandance_Management_Utility
{
    public partial class Form1 : Form
    {
        DataTable allstudents;
        bool toggle = true;
        database db = new database();
        SerialPort sp;
        int deviceId = 0;
        int fac_id;
        DataTable fac,clas,lec;
        string lecture_ID;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadCombobox();
        }

        private void LoadCombobox()
        {
            com_cmbx.DataSource = SerialPort.GetPortNames();
           // baud_cmbx.Items.Add("9600");
            baud_cmbx.Items.Add("115200");
            baud_cmbx.Text = "115200";
            DataTable dt = db.Fetch("Select * from teacher");
            fac = dt;
            foreach (DataRow drow in dt.Rows) {
                faculty_cmbx.Items.Add(drow[1]+" | "+drow[2]);
                fac_cmbx.Items.Add(drow[1] + " | " + drow[2]);
            }
        }

        private void StudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add_Student add_Student = new Add_Student();
            add_Student.ShowDialog(this);
        }

        private void TeacherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add_Teacher add_Teacher = new Add_Teacher();
            add_Teacher.ShowDialog(this);
        }

        private void DeviceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add_device add_Device = new Add_device();
            add_Device.ShowDialog(this);
        }

        private void TeacherDeviceRelationshipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            teacher_device_relationship teacher_device = new teacher_device_relationship();
            teacher_device.ShowDialog(this);
        }

        private void Connect_btn_Click(object sender, EventArgs e)
        {
            toggle = !toggle;
            if (!toggle)
            {
                connect_btn.Text = "Disconnect";
                connect_btn.BackColor = Color.Red;
                sp = new SerialPort(com_cmbx.Text, Convert.ToInt32(baud_cmbx.Text));
                sp.Open();
                sp.Write(Convert.ToString(1));
                deviceId = Convert.ToInt32(sp.ReadLine());
                att_sec.Enabled=true;
            }
            else
            {
                connect_btn.Text = "Connect";
                connect_btn.BackColor = Color.Green;
                sp.Close();
                att_sec.Enabled = false;
            }
        }
        long DateTimeToTimestamp(DateTime dt)
        {
            long epoch = (dt.ToUniversalTime().ToLocalTime().Ticks - 621355968000000000) / 10000000;
            return epoch;
        }
        private void Start_lec_attnd_btn_Click(object sender, EventArgs e)
        {
            db.InsertToDb("INSERT INTO `lectures`( `dev_id`, `starttime`, `endtime`) VALUES ("+deviceId+","+DateTimeToTimestamp(startTime.Value)+","+ DateTimeToTimestamp(endTime.Value) + ")");
            string lec_id = db.Fetch("SELECT `lecture_id` FROM `lectures` ORDER BY lecture_id DESC LIMIT 1 ").Rows[0][0].ToString();
            sp.Write(Convert.ToString(2));
            sp.Write(lec_id);
            faculty_cmbx.Text = "";
            startTime.ResetText();
            endTime.ResetText();
        }

        private void Clear_tmp_Click(object sender, EventArgs e)
        {
            sp.Write(Convert.ToString(3));
        }

        private void Fac_cmbx_SelectedIndexChanged(object sender, EventArgs e)
        {
            class_cmbx.Items.Clear();
            fac_id = Convert.ToInt32(fac.Rows[fac_cmbx.SelectedIndex][0].ToString());
            loadClass();
        }

        private void Lec_cmbx_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            string lec_id = lec.Rows[lec_cmbx.SelectedIndex][0].ToString();
            lecture_ID = lec_id;
            allstudents = db.Fetch("Select * from student");
            int j = 0;
            foreach (DataRow drow in allstudents.Rows)
            {
                dataGridView1.Rows.Add(1);
                dataGridView1.Rows[j].Cells[1].Value = drow[1];
                dataGridView1.Rows[j].Cells[0].Value = drow[2];
                    j++;
            }
            DataTable presentStudents = db.Fetch("Select student_id from attandence Where lec_id="+lec_id+"");
            foreach (DataRow drow in presentStudents.Rows) {
                int i = 0;
                foreach (DataRow drow1 in allstudents.Rows)
                {

                    if (drow[0].ToString() == drow1[3].ToString())
                    {
                        dataGridView1.Rows[i].Cells[2].Value = "P";
                        break;
                    }
                    
                    i++;
                }
            }
            foreach (DataGridViewRow drow in dataGridView1.Rows)
            {
                if (drow.Cells[2].Value==null)
                {
                    drow.Cells[2].Value = "A";
                }
            }
        }

        private void Faculty_cmbx_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = "SELECT Name,emp_id from teacher";
            DataTable dt = db.Fetch(query);
        }

        private void Update_btn_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow drow in dataGridView1.Rows)
            {
                string query = "INSERT INTO `finalattandence`(`PRN`, `Lec_id`, `Attendance`) VALUES ("+drow.Cells[0].Value+","+lecture_ID+",'"+drow.Cells[2].Value+"')";
                db.InsertToDb(query);
            }
        }

        private void loadClass()
        {
            string query = "SELECT device_id,class FROM `device` WHERE device_id=(Select device_id from `teacher-class-relation` where teacher_id="+fac_id+")";
            DataTable dt=db.Fetch(query);
            clas = dt;
            foreach (DataRow drow in dt.Rows)
            {
                class_cmbx.Items.Add(drow[1]);
            }
        }

        private void att_sec_Enter(object sender, EventArgs e)
        {

        }

        private void attand_grb_box_Enter(object sender, EventArgs e)
        {

        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

       /* private void button1_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            int i = 0;
            int j = 0;

            for (i = 0; i <= dataGridView1.RowCount - 1; i++)
            {
                for (j = 0; j <= dataGridView1.ColumnCount - 1; j++)
                {
                    DataGridViewCell cell = dataGridView1[j, i];
                    xlWorkSheet.Cells[i + 1, j + 1] = cell.Value;
                }
            }

            xlWorkBook.SaveAs("csharp.net-informations.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            MessageBox.Show("Excel file created , you can find the file c:\\csharp.net-informations.xls");

        }
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }*/

        public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(unixTimeStamp).ToLocalTime();
            return dtDateTime;
        }
        private void Class_cmbx_SelectedIndexChanged(object sender, EventArgs e)
        {
            faculty_cmbx.Items.Clear();
            deviceId = Convert.ToInt32(clas.Rows[class_cmbx.SelectedIndex][0].ToString());
        string query = "SELECT `lecture_id`, `subject`,`starttime`,`endtime` FROM `lectures`,`teacher-class-relation`,`teacher` WHERE lectures.dev_id=`teacher-class-relation`.device_id && `teacher-class-relation`.`teacher_id`=`teacher`.`id` && `teacher`.`id`="+fac_id+" && `teacher-class-relation`.`device_id`="+deviceId+"";
            DataTable dt = db.Fetch(query);
            lec = dt;
            foreach (DataRow drow in dt.Rows)
            {
                lec_cmbx.Items.Add(drow[0]+" | "+drow[1]+" | "+UnixTimeStampToDateTime( Convert.ToDouble( drow[2])));
            }
        }
    }
}

﻿namespace Attandance_Management_Utility
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teacherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deviceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teacherDeviceRelationshipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.connect_btn = new System.Windows.Forms.Button();
            this.baud_cmbx = new System.Windows.Forms.ComboBox();
            this.com_cmbx = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mySqlCommand1 = new MySql.Data.MySqlClient.MySqlCommand();
            this.att_sec = new System.Windows.Forms.GroupBox();
            this.faculty_cmbx = new System.Windows.Forms.ComboBox();
            this.start_lec_attnd_btn = new System.Windows.Forms.Button();
            this.endTime = new System.Windows.Forms.DateTimePicker();
            this.startTime = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.utility_grp_box = new System.Windows.Forms.GroupBox();
            this.clear_tmp = new System.Windows.Forms.Button();
            this.attand_grb_box = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.update_btn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.prn_col = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.att = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lec_cmbx = new System.Windows.Forms.ComboBox();
            this.class_cmbx = new System.Windows.Forms.ComboBox();
            this.fac_cmbx = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.att_sec.SuspendLayout();
            this.utility_grp_box.SuspendLayout();
            this.attand_grb_box.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1038, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentToolStripMenuItem,
            this.teacherToolStripMenuItem,
            this.deviceToolStripMenuItem,
            this.teacherDeviceRelationshipToolStripMenuItem});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.addToolStripMenuItem.Text = "Add";
            this.addToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.studentToolStripMenuItem.Text = "Student";
            this.studentToolStripMenuItem.Click += new System.EventHandler(this.StudentToolStripMenuItem_Click);
            // 
            // teacherToolStripMenuItem
            // 
            this.teacherToolStripMenuItem.Name = "teacherToolStripMenuItem";
            this.teacherToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.teacherToolStripMenuItem.Text = "Teacher";
            this.teacherToolStripMenuItem.Click += new System.EventHandler(this.TeacherToolStripMenuItem_Click);
            // 
            // deviceToolStripMenuItem
            // 
            this.deviceToolStripMenuItem.Name = "deviceToolStripMenuItem";
            this.deviceToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.deviceToolStripMenuItem.Text = "Device";
            this.deviceToolStripMenuItem.Click += new System.EventHandler(this.DeviceToolStripMenuItem_Click);
            // 
            // teacherDeviceRelationshipToolStripMenuItem
            // 
            this.teacherDeviceRelationshipToolStripMenuItem.Name = "teacherDeviceRelationshipToolStripMenuItem";
            this.teacherDeviceRelationshipToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.teacherDeviceRelationshipToolStripMenuItem.Text = "Teacher-Device Relationship";
            this.teacherDeviceRelationshipToolStripMenuItem.Click += new System.EventHandler(this.TeacherDeviceRelationshipToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.connect_btn);
            this.groupBox1.Controls.Add(this.baud_cmbx);
            this.groupBox1.Controls.Add(this.com_cmbx);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(31, 54);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 114);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Connect";
            // 
            // connect_btn
            // 
            this.connect_btn.BackColor = System.Drawing.Color.Green;
            this.connect_btn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.connect_btn.Location = new System.Drawing.Point(10, 76);
            this.connect_btn.Name = "connect_btn";
            this.connect_btn.Size = new System.Drawing.Size(75, 23);
            this.connect_btn.TabIndex = 4;
            this.connect_btn.Text = "Connect";
            this.connect_btn.UseVisualStyleBackColor = false;
            this.connect_btn.Click += new System.EventHandler(this.Connect_btn_Click);
            // 
            // baud_cmbx
            // 
            this.baud_cmbx.FormattingEnabled = true;
            this.baud_cmbx.Location = new System.Drawing.Point(77, 49);
            this.baud_cmbx.Name = "baud_cmbx";
            this.baud_cmbx.Size = new System.Drawing.Size(121, 21);
            this.baud_cmbx.TabIndex = 3;
            // 
            // com_cmbx
            // 
            this.com_cmbx.FormattingEnabled = true;
            this.com_cmbx.Location = new System.Drawing.Point(77, 17);
            this.com_cmbx.Name = "com_cmbx";
            this.com_cmbx.Size = new System.Drawing.Size(121, 21);
            this.com_cmbx.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(6, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Baudrate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "COM PORT";
            // 
            // mySqlCommand1
            // 
            this.mySqlCommand1.CacheAge = 0;
            this.mySqlCommand1.Connection = null;
            this.mySqlCommand1.EnableCaching = false;
            this.mySqlCommand1.Transaction = null;
            // 
            // att_sec
            // 
            this.att_sec.Controls.Add(this.faculty_cmbx);
            this.att_sec.Controls.Add(this.start_lec_attnd_btn);
            this.att_sec.Controls.Add(this.endTime);
            this.att_sec.Controls.Add(this.startTime);
            this.att_sec.Controls.Add(this.label5);
            this.att_sec.Controls.Add(this.label4);
            this.att_sec.Controls.Add(this.label3);
            this.att_sec.Enabled = false;
            this.att_sec.Location = new System.Drawing.Point(310, 54);
            this.att_sec.Name = "att_sec";
            this.att_sec.Size = new System.Drawing.Size(280, 161);
            this.att_sec.TabIndex = 4;
            this.att_sec.TabStop = false;
            this.att_sec.Text = "Attendance Section";
            this.att_sec.Enter += new System.EventHandler(this.att_sec_Enter);
            // 
            // faculty_cmbx
            // 
            this.faculty_cmbx.FormattingEnabled = true;
            this.faculty_cmbx.Location = new System.Drawing.Point(87, 28);
            this.faculty_cmbx.Name = "faculty_cmbx";
            this.faculty_cmbx.Size = new System.Drawing.Size(162, 21);
            this.faculty_cmbx.TabIndex = 9;
            this.faculty_cmbx.SelectedIndexChanged += new System.EventHandler(this.Faculty_cmbx_SelectedIndexChanged);
            // 
            // start_lec_attnd_btn
            // 
            this.start_lec_attnd_btn.Location = new System.Drawing.Point(13, 129);
            this.start_lec_attnd_btn.Name = "start_lec_attnd_btn";
            this.start_lec_attnd_btn.Size = new System.Drawing.Size(236, 23);
            this.start_lec_attnd_btn.TabIndex = 8;
            this.start_lec_attnd_btn.Text = "Start Lecture Attandence";
            this.start_lec_attnd_btn.UseVisualStyleBackColor = true;
            this.start_lec_attnd_btn.Click += new System.EventHandler(this.Start_lec_attnd_btn_Click);
            // 
            // endTime
            // 
            this.endTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.endTime.Location = new System.Drawing.Point(87, 96);
            this.endTime.Name = "endTime";
            this.endTime.Size = new System.Drawing.Size(162, 20);
            this.endTime.TabIndex = 7;
            // 
            // startTime
            // 
            this.startTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.startTime.Location = new System.Drawing.Point(87, 60);
            this.startTime.Name = "startTime";
            this.startTime.Size = new System.Drawing.Size(162, 20);
            this.startTime.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "End Time";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Start Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Faculty ID";
            // 
            // utility_grp_box
            // 
            this.utility_grp_box.Controls.Add(this.clear_tmp);
            this.utility_grp_box.Location = new System.Drawing.Point(627, 54);
            this.utility_grp_box.Name = "utility_grp_box";
            this.utility_grp_box.Size = new System.Drawing.Size(200, 100);
            this.utility_grp_box.TabIndex = 5;
            this.utility_grp_box.TabStop = false;
            this.utility_grp_box.Text = "Utilities";
            // 
            // clear_tmp
            // 
            this.clear_tmp.Location = new System.Drawing.Point(10, 19);
            this.clear_tmp.Name = "clear_tmp";
            this.clear_tmp.Size = new System.Drawing.Size(184, 23);
            this.clear_tmp.TabIndex = 0;
            this.clear_tmp.Text = "Clear All Fingerprints";
            this.clear_tmp.UseVisualStyleBackColor = true;
            this.clear_tmp.Click += new System.EventHandler(this.Clear_tmp_Click);
            // 
            // attand_grb_box
            // 
            this.attand_grb_box.Controls.Add(this.button1);
            this.attand_grb_box.Controls.Add(this.update_btn);
            this.attand_grb_box.Controls.Add(this.dataGridView1);
            this.attand_grb_box.Controls.Add(this.lec_cmbx);
            this.attand_grb_box.Controls.Add(this.class_cmbx);
            this.attand_grb_box.Controls.Add(this.fac_cmbx);
            this.attand_grb_box.Location = new System.Drawing.Point(60, 278);
            this.attand_grb_box.Name = "attand_grb_box";
            this.attand_grb_box.Size = new System.Drawing.Size(606, 356);
            this.attand_grb_box.TabIndex = 6;
            this.attand_grb_box.TabStop = false;
            this.attand_grb_box.Text = "Attandence Viewer";
            this.attand_grb_box.Enter += new System.EventHandler(this.attand_grb_box_Enter);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            // 
            // update_btn
            // 
            this.update_btn.Location = new System.Drawing.Point(424, 73);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(75, 23);
            this.update_btn.TabIndex = 4;
            this.update_btn.Text = "Update";
            this.update_btn.UseVisualStyleBackColor = true;
            this.update_btn.Click += new System.EventHandler(this.Update_btn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prn_col,
            this.name,
            this.att});
            this.dataGridView1.Location = new System.Drawing.Point(35, 73);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(344, 259);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // prn_col
            // 
            this.prn_col.HeaderText = "PRN";
            this.prn_col.Name = "prn_col";
            // 
            // name
            // 
            this.name.HeaderText = "Name";
            this.name.Name = "name";
            // 
            // att
            // 
            this.att.HeaderText = "Attendance";
            this.att.Name = "att";
            // 
            // lec_cmbx
            // 
            this.lec_cmbx.FormattingEnabled = true;
            this.lec_cmbx.Location = new System.Drawing.Point(331, 34);
            this.lec_cmbx.Name = "lec_cmbx";
            this.lec_cmbx.Size = new System.Drawing.Size(168, 21);
            this.lec_cmbx.TabIndex = 2;
            this.lec_cmbx.Text = "-Select Lecture-";
            this.lec_cmbx.SelectedIndexChanged += new System.EventHandler(this.Lec_cmbx_SelectedIndexChanged);
            // 
            // class_cmbx
            // 
            this.class_cmbx.FormattingEnabled = true;
            this.class_cmbx.Location = new System.Drawing.Point(190, 34);
            this.class_cmbx.Name = "class_cmbx";
            this.class_cmbx.Size = new System.Drawing.Size(121, 21);
            this.class_cmbx.TabIndex = 1;
            this.class_cmbx.Text = "-Select Class-";
            this.class_cmbx.SelectedIndexChanged += new System.EventHandler(this.Class_cmbx_SelectedIndexChanged);
            // 
            // fac_cmbx
            // 
            this.fac_cmbx.FormattingEnabled = true;
            this.fac_cmbx.Location = new System.Drawing.Point(35, 34);
            this.fac_cmbx.Name = "fac_cmbx";
            this.fac_cmbx.Size = new System.Drawing.Size(134, 21);
            this.fac_cmbx.TabIndex = 0;
            this.fac_cmbx.Text = "-Select Faculty-";
            this.fac_cmbx.SelectedIndexChanged += new System.EventHandler(this.Fac_cmbx_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1038, 530);
            this.Controls.Add(this.attand_grb_box);
            this.Controls.Add(this.utility_grp_box);
            this.Controls.Add(this.att_sec);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Attandance Management Utility";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.att_sec.ResumeLayout(false);
            this.att_sec.PerformLayout();
            this.utility_grp_box.ResumeLayout(false);
            this.attand_grb_box.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teacherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deviceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teacherDeviceRelationshipToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button connect_btn;
        private System.Windows.Forms.ComboBox baud_cmbx;
        private System.Windows.Forms.ComboBox com_cmbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private MySql.Data.MySqlClient.MySqlCommand mySqlCommand1;
        private System.Windows.Forms.GroupBox att_sec;
        private System.Windows.Forms.ComboBox faculty_cmbx;
        private System.Windows.Forms.Button start_lec_attnd_btn;
        private System.Windows.Forms.DateTimePicker endTime;
        private System.Windows.Forms.DateTimePicker startTime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox utility_grp_box;
        private System.Windows.Forms.Button clear_tmp;
        private System.Windows.Forms.GroupBox attand_grb_box;
        private System.Windows.Forms.ComboBox lec_cmbx;
        private System.Windows.Forms.ComboBox class_cmbx;
        private System.Windows.Forms.ComboBox fac_cmbx;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn prn_col;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn att;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.Button button1;
    }
}


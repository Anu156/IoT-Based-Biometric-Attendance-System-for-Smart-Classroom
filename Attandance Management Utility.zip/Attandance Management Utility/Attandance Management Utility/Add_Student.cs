﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Attandance_Management_Utility
{
    public partial class Add_Student : Form
    {
        database db = new database();
        public Add_Student()
        {
            InitializeComponent();
        }

        private void Add_student_cmbx_Click(object sender, EventArgs e)
        {
            if (IsValid())
            {
                TakeEntriesAndAddToDB();
            }
           
        }

        private bool IsValid()
        {
            if (name_txt.Text != "" && class_cmbx.Text != "" && fp_txt.Text != "" && prn_txt.Text != "")
            {
                if (phone_txt.Text.Equals("") && email_txt.Text.Equals(""))
                {
                    MessageBox.Show("Enter either of E-Mail or Phone Number.");
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                MessageBox.Show("Enter All required details.");
                return false;
            }
        }

        private void TakeEntriesAndAddToDB()
        {
            student student = new student();
            student.Name = name_txt.Text;
            student.Email = email_txt.Text;
            student.Fp_id = fp_txt.Text;
            student.Roll_number = prn_txt.Text;
            student.Contact = phone_txt.Text;
            student.Class = class_cmbx.Text;
            student.AddToDB();
            name_txt.Text = "";
            email_txt.Text = "";
            fp_txt.Text = "";
            prn_txt.Text = "";
            phone_txt.Text = "";
            class_cmbx.Text = "";
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void Name_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Prn_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Fp_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Phone_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Email_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Class_cmbx_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Title_lbl_Click(object sender, EventArgs e)
        {

        }

        private void Add_Student_Load(object sender, EventArgs e)
        {
            LoadClass();
        }

        private void LoadClass()
        {
            DataTable dt = db.Fetch("SELECT `class` FROM `device` WHERE 1");
            foreach (DataRow drow in dt.Rows)
            {
                class_cmbx.Items.Add(drow[0]);
            }
        }
    }
}

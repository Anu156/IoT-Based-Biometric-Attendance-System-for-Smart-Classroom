﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Attandance_Management_Utility
{
    class Teacher
    {
        database db = new database();

        string name, emp_id, contact, email;

        public string Name { get => name; set => name = value; }
        public string Emp_id { get => emp_id; set => emp_id = value; }
        public string Contact { get => contact; set => contact = value; }
        public string Email { get => email; set => email = value; }
        public int AddToDb()
        {
            string query = "INSERT INTO `teacher`(`Name`, `emp_id`, `contact`, `email`) VALUES ('"+Name+"','"+Emp_id+"',"+Contact+",'"+Email+"')";
            db.InsertToDb(query);
            return 0;
        }
    }
}
